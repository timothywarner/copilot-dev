
# create a new GUID
$guid = [guid]::NewGuid()

function NewFakeName {}
