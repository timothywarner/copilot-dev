# GitHub Copilot - 4hr

## PREP
- VS Code ready
- NodeGoat, DemoKB repos
- Demo checks

## 1: INTRO (60m)
- Welcome
- Copilot basics
- DEMO: Code completion
- AI risks
- Setup verify
- Q&A

## BREAK (9m)

## 2: EVERYDAY DEV (60m)
- DEMO: Functions
- Prompts
- Chat exercise
- Team standards
- Model switching
- Shortcuts

## BREAK (9m)

## 3: ADVANCED (60m)
- DEMO: Multi-file edits
- Testing tricks
- Enterprise security
- Knowledge Bases
- Refactoring tips

## BREAK (9m)

## 4: ECOSYSTEM (60m)
- Competitive landscape
- DEMO: CLI
- Extensions
- Future roadmap
- Resources

## BACKUPS
- Pre-gen examples
- Demo > theory
- Chat fallback
- Repo examples 