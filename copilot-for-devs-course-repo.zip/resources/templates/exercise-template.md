# Exercise: [Title]

## Objective
[Brief description of what the student will accomplish]

## Prerequisites
- GitHub account with Copilot access
- [Any other specific requirements]

## Time Estimate
[Estimated time to complete: 5-15 minutes]

## Instructions

### Step 1: [First Task]
[Detailed instructions]

```
[Code snippet or starting point if applicable]
```

### Step 2: [Second Task]
[Detailed instructions]

### Step 3: [Third Task]
[Detailed instructions]

## Expected Outcome
[What the student should have created/learned by the end]

## Tips
- [Helpful tip 1]
- [Helpful tip 2]

## Challenge (Optional)
[An additional challenge for advanced students]

## Solution
The solution is available at: [link to solution or path] 