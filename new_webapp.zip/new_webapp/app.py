from flask import Flask, request, render_template
import openai

openai.api_key = "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"

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
  completion = ''
  if request.method == 'POST':
    prompt = request.form.get('prompt')
    response = openai.ChatCompletion.create(
      model="gpt-3.5-turbo",
      messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": prompt}
      ]
    )
    completion = response['choices'][0]['message']['content']
  return render_template('index.html', completion=completion)

if __name__ == '__main__':
  app.run(debug=True)